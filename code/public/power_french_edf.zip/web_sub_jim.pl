
# Category=Web_Functions

#@ Misc web functions

                                # This is called by web/bin/status_line.pl
sub web_status_line {
    my $html;
    my $state;
    $html .= "|EDF Today ";
    $state=state$mode_EDF_today;;
    
    if ($state eq "BLUE"){
    $html .= qq[&nbsp;<img src='/ia5/images/EDF_BLUE.gif'  border=0>];
    }
    
    if ($state eq "WHITE"){
    $html .= qq[&nbsp;<img src='/ia5/images/EDF_WHITE.gif'  border=0>];
    }
   
    if ($state eq "RED"){
    $html .= qq[&nbsp;<img src='/ia5/images/EDF_RED.gif'  border=0>];
    }
    
    $html .= "  |  EDF Tomorrow   ";
    $state=state$mode_EDF_demain;
    
    
    if ($state eq "BLUE"){
    $html .= qq[&nbsp;<img src='/ia5/images/EDF_BLUE.gif'  border=0>];
    }
   
    if ($state eq "WHITE"){
    $html .= qq[&nbsp;<img src='/ia5/images/EDF_WHITE.gif' border=0>];
    }
    
    if ($state eq "RED"){
    $html .= qq[&nbsp;<img src='/ia5/images/EDF_RED.gif'  border=0>];
    }
    
    if ($state eq "Unknown"){
    $html .= qq[&nbsp;<img src='/ia5/images/EDF_UNKNOWN.gif'  border=0>];
    }
    
    return $html;
}

