# Category=House
#@ This gives buttons for rate and numbers and prints present status to log

# Create a widget for inputing text commands


$Text_Input = new Generic_Item;
$Move_it = new Generic_Item ;


&tk_entry("Print to Log EDF setting ", $Text_Input);
&tk_entry("Move over values ", $Move_it);


&tk_radiobutton('Heat on time ',\$Save{heat_on_time} , ['06:00', '07:15', '08:15','09:00']);
&tk_radiobutton('EDF Color now',  \$Save{EDF_color_now}, ['BLUE', 'WHITE', 'RED']);
&tk_radiobutton('EDF rate now',  \$Save{EDF_number_now}, ['1', '2', '3']);
&tk_radiobutton('EDF Color demain',  \$Save{EDF_color_demain}, ['BLUE', 'WHITE', 'RED','Unknown']);
&tk_radiobutton('EDF rate demain',  \$Save{EDF_number_demain}, ['1', '2', '3','Unknown']);
&tk_radiobutton('Power rate number',  \$Save{power_rate_number}, ['1', '2', '3','5']);
&tk_radiobutton('Hot Water rate number',  \$Save{hot_water_number} , ['1', '2', '3','5']);
&tk_radiobutton('Look ahead flag',  \$Save{look_ahead} , ['1','5']);


if ($state = state_now $Text_Input) {
    my $set_by = get_set_by $Text_Input;
    &wazoo();
    
}

if ($state = state_now $Move_it) {
    my $set_by = get_set_by $Move_it;
    move_it();
    
}

                    # Sub wazoo



sub wazoo {
    print_log "\n";
    print_log "EDF color today is $Save{EDF_color_now}";
    print_log "EDF rate number today is $Save{EDF_number_now}";
    print_log "EDF color demain is $Save{EDF_color_demain}";
    print_log "EDF rate number demain is $Save{EDF_number_demain}";
    print_log "Hot water heater should use number $Save{hot_water_number} routine";
    print_log "Other apps should use number $Save{power_rate_number} as power rate";
    print_log "Heat will come on at $Save{heat_on_time}";
    print_log "Look ahead flag set to  $Save{look_ahead}";
    print_log "\n";

  }
  

#this is to test routine that normally only runs at 06:01 in the morning
  
sub move_it {  

$mode_EDF_today -> set ($Save{EDF_color_demain});
$Save{EDF_color_now} = $Save{EDF_color_demain};
$Save{EDF_number_now} = $Save{EDF_number_demain};
$mode_EDF_demain -> set ('Unknown');
$Save{look_ahead} = 1;
    }
    