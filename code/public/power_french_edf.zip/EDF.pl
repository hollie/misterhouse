# Category=House

#@ Routine for EDF Tempo Tarif. Get email and then set numbers and colors.

#Following are set by email scan EDF


#$Save{EDF_color_demain}    Color for next day
#$Save{EDF_number_demain}   Rate number for next day
#$Save{EDF_color_now}       Color right now  
#$Save{EDF_number_now}      Rate right now 
#$Save{hot_water_number}    Number to control hot water heater 
#$Save{power_rate_number}    Number to control other electrical units



# Section to define items and buttons for display


$mode_EDF_today = new Generic_Item;
set_casesensitive $mode_EDF_today;
$mode_EDF_today -> set_states ('RED','WHITE','BLUE');
$mode_EDF_today -> set_info('The EDF Tempo tariff in today');

$mode_EDF_demain = new Generic_Item;
set_casesensitive $mode_EDF_demain;
$mode_EDF_demain -> set_states ('RED','WHITE','BLUE','Unknown');
$mode_EDF_demain -> set_info('The EDF Tempo tariff tommorrow');


# Section to check for email and set numbers and colors.
# Each day between 16:30 and 20:00 an email is sent with the rate that will be used the next day starting at 06:00
# 


                                
if (done_now $p_get_email and -e $get_email_scan_file) {
    for my $line (file_read $get_email_scan_file) {
        my ($from, $to, $subject, $body) = $line =~ /From:(.+?) To:(.+?) Subject:(.+?) Body:(.+)/;

                                
#       display  text => "$Time_Date: $subject\n", time => 0, window_name => 'debug', append => 'top';
        if ($subject =~ /Previsions Tempo : demain jour Bleu/i) {
            print_log "Tomorrow is BLUE\n";
            $Save{EDF_color_demain} = 'BLUE';
            $Save{EDF_number_demain} = 1;
            $mode_EDF_demain -> set ($Save{EDF_color_demain});
            }
            
        if ($subject =~ /Previsions Tempo : demain jour Rouge/i) {
            print_log "Tomorrow is RED\n";
            $Save{EDF_color_demain} = 'RED';
            $Save{EDF_number_demain} = 3;
            $mode_EDF_demain -> set ($Save{EDF_color_demain});
            }
            
        if ($subject =~ /Previsions Tempo : demain jour Blanc/i) {
            print_log "Tomorrow is WHITE\n";
            $Save{EDF_color_demain} = 'WHITE';
            $Save{EDF_number_demain} = 2;
            $mode_EDF_demain -> set ($Save{EDF_color_demain});
            }        
            
# Check if rate will go down and set to 5 if it will. This will mean equipment will not go on during the night
# but the next day on the lower rate. Use $Save{look_ahead} to control some equipment         
            
        if ($Save{EDF_number_demain} < $Save{EDF_number_now}){
                        $Save{look_ahead} = 5;
            }
        	
        	else 
        	
        	{
        		$Save{hot_water_number} = $Save{EDF_number_now};
            $Save{power_rate_number} = $Save{EDF_number_now} ;
          }
                   
    }
}




# set today to info from night before and clear tomorrow. Do it at 06:01 so look ahead can happen

if (time_now "06:01") {
	
$mode_EDF_today -> set ($Save{EDF_color_demain});
$Save{EDF_color_now} = $Save{EDF_color_demain};
$Save{EDF_number_now} = $Save{EDF_number_demain};
$mode_EDF_demain -> set ('Unknown');
}


# Always clear look ahead at 11:00

if (time_now "11:00"){
	$Save{look_ahead} = 1;
}