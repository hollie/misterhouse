# Category=House

#@ This controles the hot water heater. Variable 'hot_water_number' and '$Save{look_ahead}' are used to determine times to turn on.


# Setup for Tempo Tarif EDF Blue

 if ($Save{hot_water_number} == 1) {

 if (time_now "01:05") {
    set $Water_heater ON;
    print_log "Hot Water Heater turned ON for Blue rate";
}

if (time_now "06:00") {
    set $Water_heater OFF;
    }


if (time_now "06:01") {
    set $Water_heater OFF;
    print_log "Hot Water Heater turned OFF";
}
}



# Setup for Tempo Tarif EDF White

 if ($Save{hot_water_number} == 2) {

 if (time_now "03:30") {
    set $Water_heater ON;
    print_log "Hot Water Heater turned ON for White rate";
}

if (time_now "06:00") {
    set $Water_heater OFF;
    }


if (time_now "06:01") {
    set $Water_heater OFF;
    print_log "Hot Water Heater turned OFF";
}
}



# Setup for Tempo Tarif EDF RED

 if ($Save{hot_water_number} == 3) {


 if (time_now "04:00") {
    set $Water_heater ON;
    print_log "Hot Water Heater turned ON for Red rate";
}

if (time_now "06:00") {
    set $Water_heater OFF;
    }


if (time_now "06:01") {
    set $Water_heater OFF;
    print_log "Hot Water Heater turned OFF";
}
}



#  Turns on next day if the rate is lower than now in effect. Will heat fo 3 hours


 if ($Save{look_ahead} == 5) {

 if (time_now "06:01") {
    set $Water_heater ON;
    print_log "Hot Water Heater turned ON using look ahead";
}

if (time_now "09:00") {
    set $Water_heater OFF;
    }


if (time_now "09:01") {
    set $Water_heater OFF;
    print_log "Hot Water Heater turned OFF ";
}
}

