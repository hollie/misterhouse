
From Jim Morrissey on 2/2006

---------

Dear Bruce,

I have done a bit of code that may be useful for others. I am not sure just
where it can be useful except in France since not sure of what power
companies offer in other places.

Here is a bit of background on what the French national electricity (EDF)
company offers for private clients.

Normal contract:  All power is supplied at a fixed rate of 0,1057 Euros (
about 0.13 $)per Kwh and a monthly service charge of 10 Euro/month for 9KW
service.

"Heure Creuses" (Special hours): During 16 hours per day power is charged at
the same as normal rate but 8 hours a day is 0.0644 Euro (about 0.08 $) per
Kwh. The 8 hours are determined by EDF when you sign the contract a can
either be 8 hours in a row or divided into two periods like 01:00-07:00 and
12:00-14:00. The counter they put in has a relay contact that you can use to
control whatever you want and switches on when the rate is low. The idea is
that things like your water heater,washing machine,dryer etc are only
powered during the low rate. This contract has a service charge which is
15,75 Euro/month for 9KW service.

Already very easy to control your appliances with Misterhouse.

"Tempo" contract: This is the contract that makes things a bit more
complicated ! For this contract there are 6 different rates for electricity
! They keep the idea of full rate hours and special hours ( they are always
at the same time for everybody 06:00-22:00 full rate, 22:00-06:00 special
rate) but add on three different types of days in the year. They call them
BLUE,RED and WHITE. The "Tempo" year Sept 1 to August 31. During the year
there will be 301 BLUE days, 43 WHITE days and 22 RED days. The RED days can
only be between Nov.1 and March 31. The service charge is 13.53 Euro/month
for 9KW service and 18.53 Euro/month for 12 to 18 KW service.

Here is a list of what the power costs according to the color of the day.
Prices in Euro - for $US multiply by 1.2

			Normal		Special hours

BLUE			0,0553		0,0446
WHITE			0,1075		0.0907
RED			0,4702		0,1682

When they switch to a RED day one learns what the term "candlepower" really
means! (0.56 $ the Kwh)

For years now they have been putting in electronic counters that pick up the
175Hz signals they use to switch the counters to the correct rate. With the
Tempo they also give you a small box that connects to any socket in the
house and decodes the signals and gives a led readout and a buzzer when they
are going to switch to RED the next day. The indication is sent at 20:00.
Their days are 06:00 to 06:00 so it gives you time to do a lot of wash and
drying before RED comes into effect.

You can also look at their site and the information is posted around 16:30.
They also send out an email around 18:00 with the information concerning the
next day. The email always has the same format and the next day color is in
the subject.

The pl attached "EDF.pl" creates some Generic items and Save variables,
checks if an email has come in and if the next day information has arrived
will set some of the variables accordingly. $Save{look_ahead} is used by
other pl that actually control appliances. Whenever the rate will be lower
the next day, heavy power consumers no longer switch on at night but wait
till the lower rate comes into effect at 06:00 in the morning. For example
if you are on a RED day and the next day will be BLUE and the night rate
will be 0,1682 Euro/Kwh, it is better to wait till 06:00 and only pay 0,0553
Euro/Kwh.

I have also attached the pl that controls the water heater (water.pl).
Depending upon the rate the heater will run for a different amount of time
or wait until the next morning. Other pl's control the washer and dryer,
will not operate on RED days and next morning if the rate is going down.

There is a modified version of web_sub.pl (web_sub.jim.pl) that will
indicate EDF today and tomorrow. (there are also the gifs to be put in
ia5/images)

The .jpg files should be put in web/graphics and are used in the generic
items display.


"Widget_and_print.pl" is only for testing and set-up.

I would be interested to know if other power companies offer similar
complicated contracts.

Best regards,
Jim Morrissey
