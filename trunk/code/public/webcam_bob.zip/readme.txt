From Bob Hughes on 1/2004

Put snap_xcam.pl in your code_dir and the others reside in my web
dir "my_web/ia5/security". Clicking on snap picture icon in the menu will
take a picture of what is connected to your composite port... 

You will need to edit snap_xcam.pl and change the directory where the jpeg
will be written.

Have fun...

