# Grab an image from my WinTV and xcam camera.
# Called from security/*.shtml.
sub xcamgrab {
  if (qx[/bin/ps --no-headers -C xawtv]  eq '') {
      qx[/usr/bin/v4lctl setinput Composite1 2>/dev/null];
      qx[/usr/bin/streamer -q -t 1 -f jpeg -o /opt/misterhouse/my_web/captures/xcam_latest.jpeg 2>/dev/null];
      return;
  } else {
      print_log "Can't snap a picture - XAWTV is running";
      return;
  }
}
