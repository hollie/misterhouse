# Category=Lighting
#
# Main lighting control sequences

#  Turn on the Playroom & garage floods when the Workshop lights are turned off
if ($state = state_changed $workshop_lights) {
	
	if ($state eq OFF && $Dark) {
		set $playroom_flood_lights ON;
		set $garage_flood_lights ON;
		
	}
        
}
                           



#  Sunset Lighting
$lounge_wall_lights			-> tie_time( $Time_Sunset, ON);
$front_flood_lights_all		-> tie_time( "$Time_Sunset + 0:15", ON);
$front_door_lights			-> tie_time( $Time_Sunset, ON);
$ground_hall_light			-> tie_time( $Time_Sunset, ON);
$front_garden_path_lights	 -> tie_time( "$Time_Sunset + 0:15", ON);


#  End of day lights off
$front_flood_lights_all	-> tie_time( '22:00', OFF);
$front_door_lights		-> tie_time( '22:00', OFF);
#$ground_hall_light		-> tie_time( '22:00', OFF);
$front_garden_path_lights	-> tie_time( '22:00', OFF);
