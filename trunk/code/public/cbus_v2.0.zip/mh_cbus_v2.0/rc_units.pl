# Category=Test

#
# Main lighting control sequences

$v_test_morse = new  Voice_Cmd("Test Morse Beacon [Send Morse]");

if (my $data = said $v_test_morse) {
	if ($data eq 'Send Morse' ) {
		
		send_morse();

	} else {
		print_log "Send Morse: command $data is not implemented";
	}
}




#  TEST Scenarios
if ($state = state_changed $rc_unit_1_channel_2) {
	
	send_morse();	
	       
}

# Category=Lighting


#  Turn on the Playroom & Garage Floods
if (($state = state_changed $rc_unit_1_channel_1) && $Dark) {
	
	set $playroom_flood_lights		$state;
	set $garage_flood_lights		$state;
	       
}
                           
#  Turn on the Front Lights
if (($state = state_changed $rc_unit_1_channel_4) && $Dark) {
	
	set $front_flood_lights_all		$state;
	set $front_garden_path_lights	$state;	
	sleep 1;		
	set $front_door_lights		$state;
	sleep 1;
	set $ground_hall_light		$state;		
	       
}

# Reset the Radio Interface

if (time_cron('5, 3, *, *, *') ) { # 03:05 AM, every day
	
	set $rc_unit_1_channel_1	OFF;
	set $rc_unit_1_channel_2	OFF;
	set $rc_unit_1_channel_3	OFF;
	set $rc_unit_1_channel_4	OFF;
	
	set $rc_unit_2_channel_1	OFF;
	set $rc_unit_2_channel_2	OFF;
	set $rc_unit_2_channel_3	OFF;
	set $rc_unit_2_channel_4	OFF;
}	
	

sub send_morse {

	# ensure that ECHOSTATION application is running on PLUMBRULE
	# the form_data file contains the HTTP form post directoves for Lynx
	my $morse_host = "plumbrule.killara:5080";

	my $command = "lynx -post_data http://$morse_host/ < $config_parms{code_dir}" . "/form_data";
	my $result = `$command`;
	print_log "Morse Beacon: Sent";
		
}

