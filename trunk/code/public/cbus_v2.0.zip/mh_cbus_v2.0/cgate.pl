# Category	= CGATE

# Revision History: 
#	03-12-2001
#		Modified to support c-gate 1.5
#	23-06-2002
#		Monitor: Source name now works, and shows 'MH' is source 0
#	05-07-2002
#		Modified for cbus_dat.csv input file support
#		Added groups and set_info support
#	06-07-2002
#		Minor changes to support new cgate_builder.pl
#		Modified to support global %cbus_data hash
#		removed make_cbus_file(), replaced with cbus_builder.pl
#	11-07-2002
#		Added announce flag to cbus_dat.csv, and conditional speak flag $announce
#	19-09-2002
#		Fixed bug in cgate_set() that prevented dimming numeric % set values
#		being accepted.  Dimming now works.
#	21-09-2002
#		Modified cbus_groups and cbus_catagories to read from input file
#		rather than hard coded
#		Put in config item cbus_category_prefix
#		Comments in input file now allowed
#		Fixed some other minor things
#	22-09-2002 V2.0
#		Collapsed cgate_talker.pl, cgate_builder.pl and cgate_monitor.pl
#		into one new file, cgate.pl.  Now issued as V2.0.
#
#
# Copyright 2002: Richard Morgan
#
# How Cgate integrates with MH
#	All Cbus objects are defined in a standard CSV file (cbus_dat.csv), this file is
#	read in at $Reload, and a large Hash-of-Hash is created to store the CBUS objects for
#	MH.  To ensure that MH can use the CBUS objects propoerly, they are mapped
#	into a MH object called Cbus_item (actually an alias for a GEneric_Item)  This allows all
#	the good stuff in MH to work on CBUS items, as if they were an X10 (sort off).
#
#	To do this mapping, that is create the cbus $objects and matching tied Voice_cmds 
#	a sub in this file make_cbus_file() reads through the CBUS hash and creates the perl directive
#	We are in effect using MH to write its own code, this was inspired from the X!0 methods.
#	The ouput file of the builder, cbus.pl is a valid MH code module and is then read
#	in at the next reload.  
#
#	So..  Remember to RUN_BUILDER, then RELOAD code, to make a CBUS object change.
#
#	The $v_objects are all voice commands and they are used to control
#	a Cbus device from the web.  Each $v_object is tied to its respective $object.
#	In program control (testing the state of an $object, or setting a $object) are all
#	performed against the $object, although you can set the $v_object, its state will not
#	reflect any updates from the actual CBUS.
#
#	Remember, the CBUS is interactive, it can receive as well as issue commands.
#
#	So, its best to allways use the $object in your code. Moving on.  Each $object is tied
#	to an event trigger that calls the cgate_set subroutines,, notice how the last 'set_by' 
#	directive was also passed, this is to ensure that we do not create endless message loops.
#	When the cgate_set sub is called the actual CBUS device is set to that state
#	assuming it was not the CBUS that actually initiated this set in the first place, get it ?
#
#	As CGate itself repeats all commands received to it, back to MH, via 
#	the cgate monitor scripts MH listens for these commands and then sets the appropraite
#	non $object, but this is ignore if MH was in fact the source of the set.
#
#	If you understand this you are now an expert on MH objects, and a true CBUS wizard.


##############################################################################
##############################################################################
##############################################################################
##############################################################################
###########							##############
###########	Globals, Startup, Menus, Voice COmmands		##############
###########							##############
##############################################################################
##############################################################################
##############################################################################
##############################################################################


# Define Globals
my %cbus_data;
my @cbus_groups;
my @cbus_categories;
my $last_mon_state = "un-initialised";
my $last_talk_state;

# Voice Commands
$v_cgate_builder 	= new  Voice_Cmd("cgate Builder [RUN_BUILDER,DUMP_DATA]");
$v_cgate_speak 		= new  Voice_Cmd('CBUS Monitor Speak [on,off]');
$v_cgate_monitor 	= new  Voice_Cmd("CBUS Monitor [START,STOP,STATUS]");
$v_cgate_talker 	= new  Voice_Cmd("C-Gate Talker [START,STOP,STATUS]");
$v_cgate_speak 		-> tie_event( 'speak "C-BUS Speak is now $state"');


if ($Reread) {
	load_cbus_data();
}

if ($Startup) {

	# Open the IP port to the C-Gate Server Status Port
	$cgate_monitor = new  Socket_Item(undef, undef, $config_parms{cgate_mon_address});
	
	if($config_parms{system_state} eq "PROD") {
		print_log "cgate_monitor: STARTING";
		cgate_monitor_start();
	}else{
		print_log "cgate_monitor: DISABLED, as we are in DEV mode";
	}

	# Open the IP port to the C-Gate Server Control Port
	$cgate_talker = new  Socket_Item(undef, undef, $config_parms{cgate_talk_address});

	if($config_parms{system_state} eq "PROD") {
		print_log "cgate_talker: STARTING";
		cgate_talker_start();
	}else{
		print_log "cgate_talker: DISABLED, as we are in DEV mode";
	}
}


# Monitor Voice Command / Menu processing
if (my $data = said $v_cgate_monitor) {
	if ($data eq 'START' ) {
		cgate_monitor_start();
			
	} elsif ($data eq 'STOP') {
		cgate_monitor_stop();
			
	} elsif ($data eq 'STATUS') {
		cgate_monitor_status();
			
	} else {
		print_log "C-Gate_Monitor: command $data is not implemented";
	}
}

# Builder Voice Command / Menu processing
if (my $data = said $v_cgate_builder) {
	if ($data eq 'RUN_BUILDER') {
		load_cbus_data();
		build_cbus_file();
			
	} elsif ($data eq 'DUMP_DATA') {
		dump_cbus_data();
			
	} else {
		print_log "cgate_Builder: command $data is not implemented";
	}
}

# Talker Voice Command / Menu processing
if ($state = said $v_cgate_talker) {
	
	if ($state eq 'START' ) {
		cgate_talker_start();
			
	} elsif ($state eq 'STOP') {
		cgate_talker_stop();
		
	} elsif ($state eq 'STATUS') {
		cgate_talker_status();
	
	} else {
		print_log "C-Gate_Talker: command $state is not implemented";
	}
}

##############################################################################
##############################################################################
##############################################################################
##############################################################################
###########							##############
###########		CBUS BUILDER				##############
###########							##############
##############################################################################
##############################################################################
##############################################################################
##############################################################################


sub num_sort {
	# numeric sort routine, called as "sort sum_sort nnnnnnn"
	
	$a <=> $b;
}


sub load_cbus_data {
	# Reads in the CBUS definitions file, and creates the master
	# object Hash of Hash.  Also creates Arrays for Groups and Categories
		
	# clear out the hashes, MH is good at polluting its hases with reloads
	%cbus_data = ();
	@cbus_groups = ();
	@cbus_categories = ();
	
	# Load in the CBUS definitiions file
	my $filename = $config_parms{code_dir} . "/" . $config_parms{cbus_dat_file};
	print_log "cgate_Builder: Loading CBUS Data from file $filename";
	open (CF, "<$filename") 
		or print_log "cgate_Builder: Could not open $filename: $!";
	my @temp2 = <CF>;
	
	close (CF)
		or print_log "cgate_Builder: Could not close $filename: $!";
	
	# remove all the comment lines in input file
	my @temp1 = grep !/^\s*#/, @temp2;
	
	# Grab the first row (headings) then create an array of their names
	my $first_row = @temp1[0];
	chomp $first_row;
	my @headings = split /,/, $first_row;
	my $max_headings = scalar @headings;
	$headings[$max_headings -1] =~ tr/\r//d;
	print_log "cgate_Builder: $max_headings headings loaded from dat file";
	
	# Get rid of the first line, and process the entire file
	shift @temp1;

	# Step through the array of CBUS devices and stuff them into a Hash	
	foreach my $row (@temp1) {

		$row =~ s/\cM//g;	#remove all ^M
		chomp $row;
		my @details = split /,/, $row ;
		my $loop = 0;
		
		$details[2] = hex($details[2]);
		
		for ($loop = 0; $loop < $max_headings; $loop++) {
		
			$cbus_data{$details[2]}{$headings[$loop]} = $details[$loop];
		}
	}
	my $count = scalar @temp1;
	undef @temp1;
	print_log "cgate_Builder: Loaded $count CBUS devices";
	
	# Dredge for a list of CBus Group Names
	foreach my $address (sort num_sort keys %cbus_data) {
		
		my $item_group_string = $cbus_data{$address}{'group'};
		my @item_group_list = split /:/, $item_group_string;
		
		#check if the group name is in the hash, push itif no, skip if yes
		foreach my $item_group (@item_group_list) {
			if (grep m/$item_group/, @cbus_groups) {
				next;
			} else {
				push @cbus_groups, $item_group;
			}
		}
		
	}
	
	my $count = scalar @cbus_groups;
	print_log "cgate_Builder: Loaded $count CBUS groups";
	
	# Dredge for a list of CBus Category Names
	foreach my $address (sort num_sort keys %cbus_data) {
		
		my $item_category = $cbus_data{$address}{'category'};
		
		#check if the group name is in the hash, push itif no, skip if yes
		if (grep m/$item_category/, @cbus_categories) {
			next;
		} else {
			push @cbus_categories, $item_category;
		}
		
		
	}
	
	my $count = scalar @cbus_categories;
	print_log "cgate_Builder: Loaded $count CBUS categories";
}

sub dump_cbus_data {
	# Basic diagnostic routine for dumping the cbus objects hash
	
	for my $record (sort num_sort keys %cbus_data) {
		my $msg = sprintf "CBUS ID: %d\n", $record;

		for my $data (keys %{ $cbus_data{$record} } ) {
			$msg .= "$cbus_data{$record}{$data},";	
		}
		print_log $msg;
	}
}


sub build_cbus_file {
	# This sub parses through the %cbus_group array
	# and creates the file cbus.pl, which contains all the
	# item, event and group definitions for all Cbus units
	
	my $cbus_file = $config_parms{code_dir} . "/cbus.pl";
	my ($item, $name, $opts, $rows, $info);
	rename ($cbus_file,  $cbus_file . '.old')
		or print_log "Could not create backup of $cbus_file: $!";
		
	
	# _opts2 is for dimmable units, _opts1 is for relay appliances
	my @cmd_opts = ('','[on,off]', '[,on,off,5%,10%,20%,30%,40%,50%,60%,70%,80%,90%]');
	
	print_log "Saving CBUS configs to $cbus_file";
	open (CF, ">$cbus_file")
		or print_log "Could not open $cbus_file: $!";
	
	print CF "# Category=CBUS_Items\n#\n#\n";
	print CF "# Created: $Time_Now, from cbus_dat file: \"$config_parms{cbus_dat_file}\"\n";
	print CF "# This file is automatically created with the CBUS command RUN_BUILDER  -- DO NOT EDIT\n";
	print CF "#\n# -- DO NOT EDIT --\n";
	print CF "#\n#\n#\n";

	print CF "#\n# Cbus Device Summary List\n#\n";
	foreach my $address (sort num_sort keys %cbus_data) {
		$item = $cbus_data{$address}{'label'};
		$name = $item;
		$item =~ s/ /_/g;
		$item = '$' . $item;
			
		printf CF ("# %-30s  Address: %03i, %02x\tObject is: %s\n", $name, $address, $address, $item);
		$rows++;
	}


	print CF "#\n# Create Cbus_Items\n#\n";
	foreach my $address (sort num_sort keys %cbus_data) {
		$item = $cbus_data{$address}{'label'};
		$item =~ s/ /_/g;
		$item = '$' . $item;
			
		printf CF ("%-40s= new Cbus_Item;\n", $item);
		$rows++;
		
	}
	
	# This loop is more complex as we sort them via category
	
	foreach my $category (@cbus_categories) {
		my @cat_list;
		foreach my $address (sort num_sort keys %cbus_data) {
			my $item = $cbus_data{$address}{'category'};
		
			if ($item eq $category) {
				push @cat_list, $address;
			}
		}
		
		print CF "#\n# Create Cbus Voice_Cmds for Category: $category\n#\n";
		print CF "# Category=" . $config_parms{cbus_category_prefix} . "$category\n#\n";
			
		foreach my $address (@cat_list) {
			$item = $cbus_data{$address}{'label'};
			$name = $item;
			$item =~ s/ /_/g;
			$item = '$v_' . $item;
		
			$opts = $cmd_opts[$cbus_data{$address}{'states'}];
		
			printf CF ("%-40s= new Voice_Cmd \'%s %s\';\n", $item, $name, $opts);
			$rows++;
		}
		undef @cat_list;
	}

	print CF "#\n# Category=CBUS_Items\n#\n";
	print CF "#\n# Add set_info directives to Cbus Voice_Cmds\n#\n";
	foreach my $address (sort num_sort keys %cbus_data) {
		$item = $cbus_data{$address}{'label'};
		$name = $item;
		$item =~ s/ /_/g;
		$item = '$v_' . $item;
		
		$info = $cbus_data{$address}{'info'};
		
		# Now this is interesting
		# Something in the MH code parser breaks when it sees set_info in a line
		my $str1 = sprintf ("%-40s-> set", $item);
		my $str2 = sprintf ("_info (\'%s\');\n", $info);
		$str1 = $str1 . $str2;
		
		print CF ("$str1");
		
		$rows++;
		
	}

	#
	#
	#	set_states for Cbus_Items
	#
	#
	print CF "#\n# Set the Cbus_Items Command States\n#\n";
	foreach my $address (sort num_sort keys %cbus_data) {
		$item = $cbus_data{$address}{'label'};
		$item =~ s/ /_/g;
		$item = '$' . $item;
		
		#$opts = $cmd_opts[$cbus_data{$address}{'states'}]	
		
		printf CF ("%-40s -> set_states(ON,OFF);\n", $item);
		$rows++;
		
	}
	
	print CF "#\n# Create Event Ties\n#\n";
	foreach my $address (sort num_sort keys %cbus_data) {
		$item = $cbus_data{$address}{'label'};
		$item =~ s/ /_/g;
#		$item = '$v_' . $item;
		$item = '$' . $item;
		my $rstring = $item . '->{set_by}';
		printf CF ("tie_event %-29s \'cgate_set( %i, \$state, $rstring)\';\n", $item, $address);
		$rows++;
		
	}

	#
	#
	#	tie_item the $object to voice command object
	#
	#
	print CF "#\n# Create Item Ties\n#\n";
	foreach my $address (sort num_sort keys %cbus_data) {
		$item = $cbus_data{$address}{'label'};
		$item =~ s/ /_/g;
		#$item = '$v' . $item;
			
		printf CF ('tie_items $v_' . "%-29s  \$%s;\n", $item, $item);
		$rows++;
		
	}

	print CF "#\n# Create Groups\n#\n";
	foreach my $group_name (@cbus_groups) {
		$group_name = '$' . $group_name;
		printf CF ("%-40s= new Group();\n", $group_name);
		$rows++;
	}



	print CF "#\n# Assign CBus Objects to Groups\n#\n";
	foreach my $address (sort num_sort keys %cbus_data) {
		$item = $cbus_data{$address}{'label'};
		$item =~ s/ /_/g;
		$item = '$' . $item;
		
		my $item_group_string = $cbus_data{$address}{'group'};
		my @item_group_list = split /:/, $item_group_string;
		
		foreach my $item_group (@item_group_list) {
			$item_group = '$' . $item_group;
			printf CF ("%-20s-> add(%s);\n", $item_group, $item);
			$rows++;
		}
	}


	# What follows creates a sub called cbus_update()
	#	It is called by cgate_monitor.pl, whenever there is a message
	#	received from the Cbus.  This is perl code to write perl code
	#	Eval statements seem to be unstable under MH.
	
	print CF "#\n# Create Master CBus Status Subroutine\n#\n";
	print CF "sub cbus_update {\n\n";
	print CF "\t# *****************************************************************************************\n";
	print CF "\t# This subroutine is automatically generated by cgate_builder.pl, do not edit !\n";
	print CF "\t# *****************************************************************************************\n\n";
	print CF "\tmy \$addr = \$_[0];\n";
	print CF "\tmy \$newstate = \$_[1];\n";
	print CF "\tmy \$requestor = \$_[2];\n\n";

	foreach my $address (sort num_sort keys %cbus_data) {
		$item = $cbus_data{$address}{'label'};
		$item =~ s/ /_/g;
		$item = '$' . $item;
		print CF "\tif (\$addr == $address) {\n";
		print CF "\t\tset $item \$newstate;\n";
		print CF "\t\t$item" . '->{set_by}' . " = \$requestor;\n";
		print CF "\t}\n\n";
		$rows++;
	}
	
	print CF "}\n";

	print CF "#\n#\n# EOF\n#\n#\n";

	close (CF)
		or print_log "Could not close $cbus_file: $!";

	print_log "Completed CBUS configs to $cbus_file, saved $rows records";
		
}


##############################################################################
##############################################################################
##############################################################################
##############################################################################
###########							##############
###########		CBUS MONITOR				##############
###########							##############
##############################################################################
##############################################################################
##############################################################################
##############################################################################

	


sub cgate_monitor_start {
	# Start the cgate listener (monitor)
	
	if (active $cgate_monitor) {
		print_log "C-Gate_Monitor already running, skipping start";
		speak("C-Gate Monitor: is already running");

	}else{
		if (start $cgate_monitor) {
			speak("C-Gate monitor started");
			print_log "C-Gate_Monitor: started";
		}else{
			speak("C-Gate Monitor failed to start");
			print_log "C-Gate_Monitor: failed to start";
		}
	}
}

sub cgate_monitor_stop {
	# Stop the cgate listener (monitor)

	print_log "C-Gate_Monitor: Stopping";
	stop  $cgate_monitor;
	speak("C-Gate Monitor stopped");
}

sub cgate_monitor_status {
	# Return the status of the cgate listener (monitor)

	if (active $cgate_monitor) {
		print_log "C-Gate_Monitor: is active. Last event received was: $last_mon_state";
		speak("C-Gate Monitor is active. Last event received was $last_mon_state");
	}else{
		print_log "C-Gate Monitor: is not running";
		speak("C-Gate Monitor is not running");
	}		
}

# Monitor and process data comming from C-Gate server
# Executed every pass of MH

if (my $cbus_msg = said $cgate_monitor) {
	my @cg = split / /, $cbus_msg;
	my $cg_time = $cg[0];
	my $cg_code = $cg[1];
	my @cd = split /\//, $cg[2];
	my $cg_net = $cd[0];
	my $cg_app = $cd[1];
	my $cg_device = $cd[2];
	my $cg_action = $cg[3];
	my $cg_level = $cg[4];
	my $cg_source = $cg[5];
	my $cg_ramptime = $cg[6];

	my $state_speak;

	if ($cg_code == 730) {  # only code 730 are of interest

		my $level = abs(substr ($cg_level, 6, 3));
		my $source = abs(substr ($cg_source, 11));
		my $cbus_state = 0;
		
		if ($source == 251) {
			$source = "MH";
		}
		
		if ($level == 255) {
			$cbus_state = ON;
			$state_speak = ON;
		
		} elsif ($level == 0) {
			$cbus_state = OFF;
			$state_speak = OFF;
		
		} else {
			#$cbus_state = "DIM";
			my $plevel = $level /255 * 100; 
			$cbus_state = sprintf( "%.0f%%", $plevel);
			$state_speak = sprintf( "dim to %.0f%%", $plevel);
		}
		
		my $cbus_label = $cbus_data{$cg_device}{'label'};
		my $cbus_speak_name = $cbus_data{$cg_device}{'speak_name'};
		my $announce = $cbus_data{$cg_device}{'announce'};

		$last_mon_state = "$cbus_speak_name $state_speak";		
		
		if(( state $v_cgate_speak eq ON) && ($announce)) {
			speak($last_mon_state);
		}
		
		if($source eq 'MH') {
			# This is a Reflected mesg, we will ignore
		}else{
			cbus_update( $cg_device, $cbus_state, 'cgate');
			print_log "C-Gate_Monitor: $cbus_label $state_speak. Source $source";
		}
		
	}

}


##############################################################################
##############################################################################
##############################################################################
##############################################################################
###########							##############
###########		CBUS TALKER				##############
###########							##############
##############################################################################
##############################################################################
##############################################################################
##############################################################################

sub cgate_set {
	# main command handler for cgate bus directives
	
	my($device, $level, $changed_by, $speed) = @_;
	my $net_device = "1/56/" . $device;
	my $orig_level = $level;
	
	if($changed_by eq 'cgate') {
		# This was a Recursive set, we are gnoring
		return;
	}else{
		# This was NOT a recursive set, do it
	}
	
	# Get rid of any % signs in the $Level value
	$level =~ s/%//g;	
		
	if (($level eq ON) || ($level eq 'ON')) {
		$level = 100;
	
	} elsif (($level eq OFF) || ($level eq 'OFF')) {
		$level = 0;
	
	} elsif (($level <= 100) || ($level >= 0)) {
		$level = int($level);
	
	}else{
		print_log "C-Gate Talker: Unkown level \'$level\' passed to cgate_set()";
		return;
	}
	
	
	unless (defined $speed) {
		$speed = $config_parms{cbus_ramp_speed};
	}
	
	if (active $cgate_talker) {
		my $cbus_label = $cbus_data{$device}{'label'};
		print_log "C-Gate_Talker: RAMP: \'$cbus_label ($device)\' set to $orig_level, speed=$speed";
		my $ramp_command = sprintf ("RAMP %s %i%% %is\n", $net_device, $level, $speed);
		set $cgate_talker $ramp_command;
		$last_talk_state = "Ramp unit $device to level $level, speed $speed seconds";
	}else{
		print_log "C-Gate_Talker: is not running, cannot send command";
	}		

	if (my $data = said $cgate_talker) {
		print_log "C-Gate_Talker: CBUS advised: $data";
	}

}


sub cgate_talker_start {
	# Starts the cgate command driver (Talker)
	
	if (active $cgate_talker) {
		print_log "C-Gate_Talker: already running, skipping start";
		speak("C-Gate talker is already running");

	}else{
		if (start $cgate_talker) {
			speak("C-Gate talker started");
			print_log "C-Gate_Talker: started";

			if (my $data = said $cgate_talker) {
				print_log "C-Gate_Talker: CBUS advised: $data";
			}

		}else{
			speak("C-Gate Talker failed to start");
			print_log "C-Gate_Talker: failed to start";
		}
	}
}

sub cgate_talker_stop {
	# Stops the cgate command driver (Talker)

	print_log "C-Gate_Talker: Stopping";
	stop  $cgate_talker;
	speak("C-Gate talker stopped");
}

sub cgate_talker_status {
	# Returns the status of the cgate command driver (Talker)

	if (active $cgate_talker) {
		print_log "C-Gate_Talker: is active. Last command sent was: $last_talk_state";
		speak("C-Gate Talker is active. Last command sent was $last_talk_state");
	}else{
		print_log "C-Gate_Talker: is not running";
		speak("C-Gate Talker is not running");
	}		
}





		


