# Category=CBUS_Items
#
#
# Created: 11:48 AM, from cbus_dat file: "cbus_dat.csv"
# This file is automatically created with the CBUS command RUN_BUILDER  -- DO NOT EDIT
#
# -- DO NOT EDIT --
#
#
#
#
# Cbus Device Summary List
#
# garage door                     Address: 000, 00	Object is: $garage_door
# workshop power                  Address: 001, 01	Object is: $workshop_power
# playroom lights                 Address: 002, 02	Object is: $playroom_lights
# workshop lights                 Address: 003, 03	Object is: $workshop_lights
# playroom toilet light           Address: 004, 04	Object is: $playroom_toilet_light
# playroom lights all             Address: 005, 05	Object is: $playroom_lights_all
# front garden path lights        Address: 006, 06	Object is: $front_garden_path_lights
# playroom flood lights           Address: 007, 07	Object is: $playroom_flood_lights
# garage flood lights             Address: 008, 08	Object is: $garage_flood_lights
# front garden gpo                Address: 009, 09	Object is: $front_garden_gpo
# lounge wall lights              Address: 010, 0a	Object is: $lounge_wall_lights
# cellar door light               Address: 011, 0b	Object is: $cellar_door_light
# cbus test unit                  Address: 012, 0c	Object is: $cbus_test_unit
# lounge down lights centre       Address: 016, 10	Object is: $lounge_down_lights_centre
# lounge down lights far          Address: 017, 11	Object is: $lounge_down_lights_far
# all flood lights                Address: 018, 12	Object is: $all_flood_lights
# ground hall light               Address: 019, 13	Object is: $ground_hall_light
# lounge down lights near         Address: 020, 14	Object is: $lounge_down_lights_near
# front flood lights west         Address: 021, 15	Object is: $front_flood_lights_west
# front flood lights east         Address: 022, 16	Object is: $front_flood_lights_east
# front door lights               Address: 023, 17	Object is: $front_door_lights
# front flood lights all          Address: 024, 18	Object is: $front_flood_lights_all
# playroom lights hold            Address: 025, 19	Object is: $playroom_lights_hold
# main bath light                 Address: 027, 1b	Object is: $main_bath_light
# main bath fan                   Address: 028, 1c	Object is: $main_bath_fan
# main bath heat light 1          Address: 029, 1d	Object is: $main_bath_heat_light_1
# main bath heat light 2          Address: 030, 1e	Object is: $main_bath_heat_light_2
# ensuite light                   Address: 031, 1f	Object is: $ensuite_light
# ensuite fan                     Address: 032, 20	Object is: $ensuite_fan
# rc unit 2 channel 1             Address: 033, 21	Object is: $rc_unit_2_channel_1
# rc unit 2 channel 2             Address: 034, 22	Object is: $rc_unit_2_channel_2
# rc unit 2 channel 3             Address: 035, 23	Object is: $rc_unit_2_channel_3
# rc unit 2 channel 4             Address: 036, 24	Object is: $rc_unit_2_channel_4
# ensuite heat light              Address: 037, 25	Object is: $ensuite_heat_light
# garage flood lights hold        Address: 038, 26	Object is: $garage_flood_lights_hold
# playroom flood lights hold      Address: 039, 27	Object is: $playroom_flood_lights_hold
# rc unit 1 channel 1             Address: 040, 28	Object is: $rc_unit_1_channel_1
# rc unit 1 channel 2             Address: 041, 29	Object is: $rc_unit_1_channel_2
# rc unit 1 channel 3             Address: 042, 2a	Object is: $rc_unit_1_channel_3
# rc unit 1 channel 4             Address: 043, 2b	Object is: $rc_unit_1_channel_4
# ws fnt main                     Address: 044, 2c	Object is: $ws_fnt_main
# ws fnt side bed                 Address: 045, 2d	Object is: $ws_fnt_side_bed
# ws fnt beds                     Address: 046, 2e	Object is: $ws_fnt_beds
# ws fnt lawn                     Address: 047, 2f	Object is: $ws_fnt_lawn
# ws rear main                    Address: 048, 30	Object is: $ws_rear_main
# ws rear herbs                   Address: 049, 31	Object is: $ws_rear_herbs
# ws rear garage                  Address: 050, 32	Object is: $ws_rear_garage
# ws fnt spare1                   Address: 051, 33	Object is: $ws_fnt_spare1
# ws fnt spare2                   Address: 052, 34	Object is: $ws_fnt_spare2
# ws fnt spare3                   Address: 053, 35	Object is: $ws_fnt_spare3
# cellar aux power                Address: 054, 36	Object is: $cellar_aux_power
# cbus unused unit                Address: 255, ff	Object is: $cbus_unused_unit
#
# Create Cbus_Items
#
$garage_door                            = new Cbus_Item;
$workshop_power                         = new Cbus_Item;
$playroom_lights                        = new Cbus_Item;
$workshop_lights                        = new Cbus_Item;
$playroom_toilet_light                  = new Cbus_Item;
$playroom_lights_all                    = new Cbus_Item;
$front_garden_path_lights               = new Cbus_Item;
$playroom_flood_lights                  = new Cbus_Item;
$garage_flood_lights                    = new Cbus_Item;
$front_garden_gpo                       = new Cbus_Item;
$lounge_wall_lights                     = new Cbus_Item;
$cellar_door_light                      = new Cbus_Item;
$cbus_test_unit                         = new Cbus_Item;
$lounge_down_lights_centre              = new Cbus_Item;
$lounge_down_lights_far                 = new Cbus_Item;
$all_flood_lights                       = new Cbus_Item;
$ground_hall_light                      = new Cbus_Item;
$lounge_down_lights_near                = new Cbus_Item;
$front_flood_lights_west                = new Cbus_Item;
$front_flood_lights_east                = new Cbus_Item;
$front_door_lights                      = new Cbus_Item;
$front_flood_lights_all                 = new Cbus_Item;
$playroom_lights_hold                   = new Cbus_Item;
$main_bath_light                        = new Cbus_Item;
$main_bath_fan                          = new Cbus_Item;
$main_bath_heat_light_1                 = new Cbus_Item;
$main_bath_heat_light_2                 = new Cbus_Item;
$ensuite_light                          = new Cbus_Item;
$ensuite_fan                            = new Cbus_Item;
$rc_unit_2_channel_1                    = new Cbus_Item;
$rc_unit_2_channel_2                    = new Cbus_Item;
$rc_unit_2_channel_3                    = new Cbus_Item;
$rc_unit_2_channel_4                    = new Cbus_Item;
$ensuite_heat_light                     = new Cbus_Item;
$garage_flood_lights_hold               = new Cbus_Item;
$playroom_flood_lights_hold             = new Cbus_Item;
$rc_unit_1_channel_1                    = new Cbus_Item;
$rc_unit_1_channel_2                    = new Cbus_Item;
$rc_unit_1_channel_3                    = new Cbus_Item;
$rc_unit_1_channel_4                    = new Cbus_Item;
$ws_fnt_main                            = new Cbus_Item;
$ws_fnt_side_bed                        = new Cbus_Item;
$ws_fnt_beds                            = new Cbus_Item;
$ws_fnt_lawn                            = new Cbus_Item;
$ws_rear_main                           = new Cbus_Item;
$ws_rear_herbs                          = new Cbus_Item;
$ws_rear_garage                         = new Cbus_Item;
$ws_fnt_spare1                          = new Cbus_Item;
$ws_fnt_spare2                          = new Cbus_Item;
$ws_fnt_spare3                          = new Cbus_Item;
$cellar_aux_power                       = new Cbus_Item;
$cbus_unused_unit                       = new Cbus_Item;
#
# Create Cbus Voice_Cmds for Category: Workshop
#
# Category=__Workshop
#
$v_garage_door                          = new Voice_Cmd 'garage door [on,off]';
$v_workshop_power                       = new Voice_Cmd 'workshop power [on,off]';
$v_playroom_lights                      = new Voice_Cmd 'playroom lights [on,off]';
$v_workshop_lights                      = new Voice_Cmd 'workshop lights [on,off]';
$v_playroom_toilet_light                = new Voice_Cmd 'playroom toilet light [on,off]';
$v_playroom_lights_all                  = new Voice_Cmd 'playroom lights all [on,off]';
$v_playroom_flood_lights                = new Voice_Cmd 'playroom flood lights [on,off]';
$v_garage_flood_lights                  = new Voice_Cmd 'garage flood lights [on,off]';
$v_cbus_test_unit                       = new Voice_Cmd 'cbus test unit [on,off]';
$v_playroom_lights_hold                 = new Voice_Cmd 'playroom lights hold [on,off]';
$v_garage_flood_lights_hold             = new Voice_Cmd 'garage flood lights hold [on,off]';
$v_playroom_flood_lights_hold           = new Voice_Cmd 'playroom flood lights hold [on,off]';
$v_cbus_unused_unit                     = new Voice_Cmd 'cbus unused unit [on,off]';
#
# Create Cbus Voice_Cmds for Category: Outside
#
# Category=__Outside
#
$v_front_garden_path_lights             = new Voice_Cmd 'front garden path lights [on,off]';
$v_front_garden_gpo                     = new Voice_Cmd 'front garden gpo [on,off]';
$v_cellar_door_light                    = new Voice_Cmd 'cellar door light [on,off]';
$v_all_flood_lights                     = new Voice_Cmd 'all flood lights [on,off]';
$v_front_flood_lights_west              = new Voice_Cmd 'front flood lights west [,on,off,5%,10%,20%,30%,40%,50%,60%,70%,80%,90%]';
$v_front_flood_lights_east              = new Voice_Cmd 'front flood lights east [,on,off,5%,10%,20%,30%,40%,50%,60%,70%,80%,90%]';
$v_front_door_lights                    = new Voice_Cmd 'front door lights [,on,off,5%,10%,20%,30%,40%,50%,60%,70%,80%,90%]';
$v_front_flood_lights_all               = new Voice_Cmd 'front flood lights all [,on,off,5%,10%,20%,30%,40%,50%,60%,70%,80%,90%]';
$v_rc_unit_2_channel_1                  = new Voice_Cmd 'rc unit 2 channel 1 [on,off]';
$v_rc_unit_2_channel_2                  = new Voice_Cmd 'rc unit 2 channel 2 [on,off]';
$v_rc_unit_2_channel_3                  = new Voice_Cmd 'rc unit 2 channel 3 [on,off]';
$v_rc_unit_2_channel_4                  = new Voice_Cmd 'rc unit 2 channel 4 [on,off]';
$v_rc_unit_1_channel_1                  = new Voice_Cmd 'rc unit 1 channel 1 [on,off]';
$v_rc_unit_1_channel_2                  = new Voice_Cmd 'rc unit 1 channel 2 [on,off]';
$v_rc_unit_1_channel_3                  = new Voice_Cmd 'rc unit 1 channel 3 [on,off]';
$v_rc_unit_1_channel_4                  = new Voice_Cmd 'rc unit 1 channel 4 [on,off]';
$v_ws_fnt_main                          = new Voice_Cmd 'ws fnt main [on,off]';
$v_ws_fnt_side_bed                      = new Voice_Cmd 'ws fnt side bed [on,off]';
$v_ws_fnt_beds                          = new Voice_Cmd 'ws fnt beds [on,off]';
$v_ws_fnt_lawn                          = new Voice_Cmd 'ws fnt lawn [on,off]';
$v_ws_rear_main                         = new Voice_Cmd 'ws rear main [on,off]';
$v_ws_rear_herbs                        = new Voice_Cmd 'ws rear herbs [on,off]';
$v_ws_rear_garage                       = new Voice_Cmd 'ws rear garage [on,off]';
$v_ws_fnt_spare1                        = new Voice_Cmd 'ws fnt spare1 [on,off]';
$v_ws_fnt_spare2                        = new Voice_Cmd 'ws fnt spare2 [on,off]';
$v_ws_fnt_spare3                        = new Voice_Cmd 'ws fnt spare3 [on,off]';
$v_cellar_aux_power                     = new Voice_Cmd 'cellar aux power [on,off]';
#
# Create Cbus Voice_Cmds for Category: Downstairs
#
# Category=__Downstairs
#
$v_lounge_wall_lights                   = new Voice_Cmd 'lounge wall lights [,on,off,5%,10%,20%,30%,40%,50%,60%,70%,80%,90%]';
$v_lounge_down_lights_centre            = new Voice_Cmd 'lounge down lights centre [,on,off,5%,10%,20%,30%,40%,50%,60%,70%,80%,90%]';
$v_lounge_down_lights_far               = new Voice_Cmd 'lounge down lights far [,on,off,5%,10%,20%,30%,40%,50%,60%,70%,80%,90%]';
$v_ground_hall_light                    = new Voice_Cmd 'ground hall light [,on,off,5%,10%,20%,30%,40%,50%,60%,70%,80%,90%]';
$v_lounge_down_lights_near              = new Voice_Cmd 'lounge down lights near [,on,off,5%,10%,20%,30%,40%,50%,60%,70%,80%,90%]';
#
# Create Cbus Voice_Cmds for Category: Upstairs
#
# Category=__Upstairs
#
$v_main_bath_light                      = new Voice_Cmd 'main bath light [on,off]';
$v_main_bath_fan                        = new Voice_Cmd 'main bath fan [on,off]';
$v_main_bath_heat_light_1               = new Voice_Cmd 'main bath heat light 1 [on,off]';
$v_main_bath_heat_light_2               = new Voice_Cmd 'main bath heat light 2 [on,off]';
$v_ensuite_light                        = new Voice_Cmd 'ensuite light [on,off]';
$v_ensuite_fan                          = new Voice_Cmd 'ensuite fan [on,off]';
$v_ensuite_heat_light                   = new Voice_Cmd 'ensuite heat light [on,off]';
#
# Category=CBUS_Items
#
#
# Add set_info directives to Cbus Voice_Cmds
#
$v_garage_door                          -> set_info ('Item 12');
$v_workshop_power                       -> set_info ('Item 16');
$v_playroom_lights                      -> set_info ('Item 29');
$v_workshop_lights                      -> set_info ('Item 15');
$v_playroom_toilet_light                -> set_info ('Item 31');
$v_playroom_lights_all                  -> set_info ('Item 26');
$v_front_garden_path_lights             -> set_info ('Item 6');
$v_playroom_flood_lights                -> set_info ('Item 27');
$v_garage_flood_lights                  -> set_info ('Item 13');
$v_front_garden_gpo                     -> set_info ('Item 7');
$v_lounge_wall_lights                   -> set_info ('Item 21');
$v_cellar_door_light                    -> set_info ('Item 2');
$v_cbus_test_unit                       -> set_info ('Item 32');
$v_lounge_down_lights_centre            -> set_info ('Item 18');
$v_lounge_down_lights_far               -> set_info ('Item 19');
$v_all_flood_lights                     -> set_info ('Item 1');
$v_ground_hall_light                    -> set_info ('Item 17');
$v_lounge_down_lights_near              -> set_info ('Item 20');
$v_front_flood_lights_west              -> set_info ('Item 11');
$v_front_flood_lights_east              -> set_info ('Item 10');
$v_front_door_lights                    -> set_info ('Item 8');
$v_front_flood_lights_all               -> set_info ('Item 9');
$v_playroom_lights_hold                 -> set_info ('Item 30');
$v_main_bath_light                      -> set_info ('Item 25');
$v_main_bath_fan                        -> set_info ('Item 22');
$v_main_bath_heat_light_1               -> set_info ('Item 23');
$v_main_bath_heat_light_2               -> set_info ('Item 24');
$v_ensuite_light                        -> set_info ('Item 5');
$v_ensuite_fan                          -> set_info ('Item 3');
$v_rc_unit_2_channel_1                  -> set_info ('Item 38');
$v_rc_unit_2_channel_2                  -> set_info ('Item 39');
$v_rc_unit_2_channel_3                  -> set_info ('Item 40');
$v_rc_unit_2_channel_4                  -> set_info ('Item 41');
$v_ensuite_heat_light                   -> set_info ('Item 4');
$v_garage_flood_lights_hold             -> set_info ('Item 14');
$v_playroom_flood_lights_hold           -> set_info ('Item 28');
$v_rc_unit_1_channel_1                  -> set_info ('Item 34');
$v_rc_unit_1_channel_2                  -> set_info ('Item 35');
$v_rc_unit_1_channel_3                  -> set_info ('Item 36');
$v_rc_unit_1_channel_4                  -> set_info ('Item 37');
$v_ws_fnt_main                          -> set_info ('Item 44');
$v_ws_fnt_side_bed                      -> set_info ('Item 45');
$v_ws_fnt_beds                          -> set_info ('Item 42');
$v_ws_fnt_lawn                          -> set_info ('Item 43');
$v_ws_rear_main                         -> set_info ('Item 51');
$v_ws_rear_herbs                        -> set_info ('Item 50');
$v_ws_rear_garage                       -> set_info ('Item 49');
$v_ws_fnt_spare1                        -> set_info ('Item 46');
$v_ws_fnt_spare2                        -> set_info ('Item 47');
$v_ws_fnt_spare3                        -> set_info ('Item 48');
$v_cellar_aux_power                     -> set_info ('Item 52');
$v_cbus_unused_unit                     -> set_info ('Item 33');
#
# Set the Cbus_Items Command States
#
$garage_door                             -> set_states(ON,OFF);
$workshop_power                          -> set_states(ON,OFF);
$playroom_lights                         -> set_states(ON,OFF);
$workshop_lights                         -> set_states(ON,OFF);
$playroom_toilet_light                   -> set_states(ON,OFF);
$playroom_lights_all                     -> set_states(ON,OFF);
$front_garden_path_lights                -> set_states(ON,OFF);
$playroom_flood_lights                   -> set_states(ON,OFF);
$garage_flood_lights                     -> set_states(ON,OFF);
$front_garden_gpo                        -> set_states(ON,OFF);
$lounge_wall_lights                      -> set_states(ON,OFF);
$cellar_door_light                       -> set_states(ON,OFF);
$cbus_test_unit                          -> set_states(ON,OFF);
$lounge_down_lights_centre               -> set_states(ON,OFF);
$lounge_down_lights_far                  -> set_states(ON,OFF);
$all_flood_lights                        -> set_states(ON,OFF);
$ground_hall_light                       -> set_states(ON,OFF);
$lounge_down_lights_near                 -> set_states(ON,OFF);
$front_flood_lights_west                 -> set_states(ON,OFF);
$front_flood_lights_east                 -> set_states(ON,OFF);
$front_door_lights                       -> set_states(ON,OFF);
$front_flood_lights_all                  -> set_states(ON,OFF);
$playroom_lights_hold                    -> set_states(ON,OFF);
$main_bath_light                         -> set_states(ON,OFF);
$main_bath_fan                           -> set_states(ON,OFF);
$main_bath_heat_light_1                  -> set_states(ON,OFF);
$main_bath_heat_light_2                  -> set_states(ON,OFF);
$ensuite_light                           -> set_states(ON,OFF);
$ensuite_fan                             -> set_states(ON,OFF);
$rc_unit_2_channel_1                     -> set_states(ON,OFF);
$rc_unit_2_channel_2                     -> set_states(ON,OFF);
$rc_unit_2_channel_3                     -> set_states(ON,OFF);
$rc_unit_2_channel_4                     -> set_states(ON,OFF);
$ensuite_heat_light                      -> set_states(ON,OFF);
$garage_flood_lights_hold                -> set_states(ON,OFF);
$playroom_flood_lights_hold              -> set_states(ON,OFF);
$rc_unit_1_channel_1                     -> set_states(ON,OFF);
$rc_unit_1_channel_2                     -> set_states(ON,OFF);
$rc_unit_1_channel_3                     -> set_states(ON,OFF);
$rc_unit_1_channel_4                     -> set_states(ON,OFF);
$ws_fnt_main                             -> set_states(ON,OFF);
$ws_fnt_side_bed                         -> set_states(ON,OFF);
$ws_fnt_beds                             -> set_states(ON,OFF);
$ws_fnt_lawn                             -> set_states(ON,OFF);
$ws_rear_main                            -> set_states(ON,OFF);
$ws_rear_herbs                           -> set_states(ON,OFF);
$ws_rear_garage                          -> set_states(ON,OFF);
$ws_fnt_spare1                           -> set_states(ON,OFF);
$ws_fnt_spare2                           -> set_states(ON,OFF);
$ws_fnt_spare3                           -> set_states(ON,OFF);
$cellar_aux_power                        -> set_states(ON,OFF);
$cbus_unused_unit                        -> set_states(ON,OFF);
#
# Create Event Ties
#
tie_event $garage_door                  'cgate_set( 0, $state, $garage_door->{set_by})';
tie_event $workshop_power               'cgate_set( 1, $state, $workshop_power->{set_by})';
tie_event $playroom_lights              'cgate_set( 2, $state, $playroom_lights->{set_by})';
tie_event $workshop_lights              'cgate_set( 3, $state, $workshop_lights->{set_by})';
tie_event $playroom_toilet_light        'cgate_set( 4, $state, $playroom_toilet_light->{set_by})';
tie_event $playroom_lights_all          'cgate_set( 5, $state, $playroom_lights_all->{set_by})';
tie_event $front_garden_path_lights     'cgate_set( 6, $state, $front_garden_path_lights->{set_by})';
tie_event $playroom_flood_lights        'cgate_set( 7, $state, $playroom_flood_lights->{set_by})';
tie_event $garage_flood_lights          'cgate_set( 8, $state, $garage_flood_lights->{set_by})';
tie_event $front_garden_gpo             'cgate_set( 9, $state, $front_garden_gpo->{set_by})';
tie_event $lounge_wall_lights           'cgate_set( 10, $state, $lounge_wall_lights->{set_by})';
tie_event $cellar_door_light            'cgate_set( 11, $state, $cellar_door_light->{set_by})';
tie_event $cbus_test_unit               'cgate_set( 12, $state, $cbus_test_unit->{set_by})';
tie_event $lounge_down_lights_centre    'cgate_set( 16, $state, $lounge_down_lights_centre->{set_by})';
tie_event $lounge_down_lights_far       'cgate_set( 17, $state, $lounge_down_lights_far->{set_by})';
tie_event $all_flood_lights             'cgate_set( 18, $state, $all_flood_lights->{set_by})';
tie_event $ground_hall_light            'cgate_set( 19, $state, $ground_hall_light->{set_by})';
tie_event $lounge_down_lights_near      'cgate_set( 20, $state, $lounge_down_lights_near->{set_by})';
tie_event $front_flood_lights_west      'cgate_set( 21, $state, $front_flood_lights_west->{set_by})';
tie_event $front_flood_lights_east      'cgate_set( 22, $state, $front_flood_lights_east->{set_by})';
tie_event $front_door_lights            'cgate_set( 23, $state, $front_door_lights->{set_by})';
tie_event $front_flood_lights_all       'cgate_set( 24, $state, $front_flood_lights_all->{set_by})';
tie_event $playroom_lights_hold         'cgate_set( 25, $state, $playroom_lights_hold->{set_by})';
tie_event $main_bath_light              'cgate_set( 27, $state, $main_bath_light->{set_by})';
tie_event $main_bath_fan                'cgate_set( 28, $state, $main_bath_fan->{set_by})';
tie_event $main_bath_heat_light_1       'cgate_set( 29, $state, $main_bath_heat_light_1->{set_by})';
tie_event $main_bath_heat_light_2       'cgate_set( 30, $state, $main_bath_heat_light_2->{set_by})';
tie_event $ensuite_light                'cgate_set( 31, $state, $ensuite_light->{set_by})';
tie_event $ensuite_fan                  'cgate_set( 32, $state, $ensuite_fan->{set_by})';
tie_event $rc_unit_2_channel_1          'cgate_set( 33, $state, $rc_unit_2_channel_1->{set_by})';
tie_event $rc_unit_2_channel_2          'cgate_set( 34, $state, $rc_unit_2_channel_2->{set_by})';
tie_event $rc_unit_2_channel_3          'cgate_set( 35, $state, $rc_unit_2_channel_3->{set_by})';
tie_event $rc_unit_2_channel_4          'cgate_set( 36, $state, $rc_unit_2_channel_4->{set_by})';
tie_event $ensuite_heat_light           'cgate_set( 37, $state, $ensuite_heat_light->{set_by})';
tie_event $garage_flood_lights_hold     'cgate_set( 38, $state, $garage_flood_lights_hold->{set_by})';
tie_event $playroom_flood_lights_hold   'cgate_set( 39, $state, $playroom_flood_lights_hold->{set_by})';
tie_event $rc_unit_1_channel_1          'cgate_set( 40, $state, $rc_unit_1_channel_1->{set_by})';
tie_event $rc_unit_1_channel_2          'cgate_set( 41, $state, $rc_unit_1_channel_2->{set_by})';
tie_event $rc_unit_1_channel_3          'cgate_set( 42, $state, $rc_unit_1_channel_3->{set_by})';
tie_event $rc_unit_1_channel_4          'cgate_set( 43, $state, $rc_unit_1_channel_4->{set_by})';
tie_event $ws_fnt_main                  'cgate_set( 44, $state, $ws_fnt_main->{set_by})';
tie_event $ws_fnt_side_bed              'cgate_set( 45, $state, $ws_fnt_side_bed->{set_by})';
tie_event $ws_fnt_beds                  'cgate_set( 46, $state, $ws_fnt_beds->{set_by})';
tie_event $ws_fnt_lawn                  'cgate_set( 47, $state, $ws_fnt_lawn->{set_by})';
tie_event $ws_rear_main                 'cgate_set( 48, $state, $ws_rear_main->{set_by})';
tie_event $ws_rear_herbs                'cgate_set( 49, $state, $ws_rear_herbs->{set_by})';
tie_event $ws_rear_garage               'cgate_set( 50, $state, $ws_rear_garage->{set_by})';
tie_event $ws_fnt_spare1                'cgate_set( 51, $state, $ws_fnt_spare1->{set_by})';
tie_event $ws_fnt_spare2                'cgate_set( 52, $state, $ws_fnt_spare2->{set_by})';
tie_event $ws_fnt_spare3                'cgate_set( 53, $state, $ws_fnt_spare3->{set_by})';
tie_event $cellar_aux_power             'cgate_set( 54, $state, $cellar_aux_power->{set_by})';
tie_event $cbus_unused_unit             'cgate_set( 255, $state, $cbus_unused_unit->{set_by})';
#
# Create Item Ties
#
tie_items $v_garage_door                    $garage_door;
tie_items $v_workshop_power                 $workshop_power;
tie_items $v_playroom_lights                $playroom_lights;
tie_items $v_workshop_lights                $workshop_lights;
tie_items $v_playroom_toilet_light          $playroom_toilet_light;
tie_items $v_playroom_lights_all            $playroom_lights_all;
tie_items $v_front_garden_path_lights       $front_garden_path_lights;
tie_items $v_playroom_flood_lights          $playroom_flood_lights;
tie_items $v_garage_flood_lights            $garage_flood_lights;
tie_items $v_front_garden_gpo               $front_garden_gpo;
tie_items $v_lounge_wall_lights             $lounge_wall_lights;
tie_items $v_cellar_door_light              $cellar_door_light;
tie_items $v_cbus_test_unit                 $cbus_test_unit;
tie_items $v_lounge_down_lights_centre      $lounge_down_lights_centre;
tie_items $v_lounge_down_lights_far         $lounge_down_lights_far;
tie_items $v_all_flood_lights               $all_flood_lights;
tie_items $v_ground_hall_light              $ground_hall_light;
tie_items $v_lounge_down_lights_near        $lounge_down_lights_near;
tie_items $v_front_flood_lights_west        $front_flood_lights_west;
tie_items $v_front_flood_lights_east        $front_flood_lights_east;
tie_items $v_front_door_lights              $front_door_lights;
tie_items $v_front_flood_lights_all         $front_flood_lights_all;
tie_items $v_playroom_lights_hold           $playroom_lights_hold;
tie_items $v_main_bath_light                $main_bath_light;
tie_items $v_main_bath_fan                  $main_bath_fan;
tie_items $v_main_bath_heat_light_1         $main_bath_heat_light_1;
tie_items $v_main_bath_heat_light_2         $main_bath_heat_light_2;
tie_items $v_ensuite_light                  $ensuite_light;
tie_items $v_ensuite_fan                    $ensuite_fan;
tie_items $v_rc_unit_2_channel_1            $rc_unit_2_channel_1;
tie_items $v_rc_unit_2_channel_2            $rc_unit_2_channel_2;
tie_items $v_rc_unit_2_channel_3            $rc_unit_2_channel_3;
tie_items $v_rc_unit_2_channel_4            $rc_unit_2_channel_4;
tie_items $v_ensuite_heat_light             $ensuite_heat_light;
tie_items $v_garage_flood_lights_hold       $garage_flood_lights_hold;
tie_items $v_playroom_flood_lights_hold     $playroom_flood_lights_hold;
tie_items $v_rc_unit_1_channel_1            $rc_unit_1_channel_1;
tie_items $v_rc_unit_1_channel_2            $rc_unit_1_channel_2;
tie_items $v_rc_unit_1_channel_3            $rc_unit_1_channel_3;
tie_items $v_rc_unit_1_channel_4            $rc_unit_1_channel_4;
tie_items $v_ws_fnt_main                    $ws_fnt_main;
tie_items $v_ws_fnt_side_bed                $ws_fnt_side_bed;
tie_items $v_ws_fnt_beds                    $ws_fnt_beds;
tie_items $v_ws_fnt_lawn                    $ws_fnt_lawn;
tie_items $v_ws_rear_main                   $ws_rear_main;
tie_items $v_ws_rear_herbs                  $ws_rear_herbs;
tie_items $v_ws_rear_garage                 $ws_rear_garage;
tie_items $v_ws_fnt_spare1                  $ws_fnt_spare1;
tie_items $v_ws_fnt_spare2                  $ws_fnt_spare2;
tie_items $v_ws_fnt_spare3                  $ws_fnt_spare3;
tie_items $v_cellar_aux_power               $cellar_aux_power;
tie_items $v_cbus_unused_unit               $cbus_unused_unit;
#
# Create Groups
#
$Devices                                = new Group();
$Lights                                 = new Group();
$Security                               = new Group();
$Garden                                 = new Group();
$CBUS_Test                              = new Group();
$Ventilation                            = new Group();
$Heating                                = new Group();
$Wireless                               = new Group();
$Sprinklers                             = new Group();
#
# Assign CBus Objects to Groups
#
$Devices            -> add($garage_door);
$Devices            -> add($workshop_power);
$Lights             -> add($playroom_lights);
$Lights             -> add($workshop_lights);
$Lights             -> add($playroom_toilet_light);
$Lights             -> add($playroom_lights_all);
$Lights             -> add($front_garden_path_lights);
$Security           -> add($front_garden_path_lights);
$Garden             -> add($front_garden_path_lights);
$Lights             -> add($playroom_flood_lights);
$Security           -> add($playroom_flood_lights);
$Lights             -> add($garage_flood_lights);
$Security           -> add($garage_flood_lights);
$Lights             -> add($front_garden_gpo);
$Security           -> add($front_garden_gpo);
$Garden             -> add($front_garden_gpo);
$Lights             -> add($lounge_wall_lights);
$Lights             -> add($cellar_door_light);
$Security           -> add($cellar_door_light);
$CBUS_Test          -> add($cbus_test_unit);
$Lights             -> add($lounge_down_lights_centre);
$Lights             -> add($lounge_down_lights_far);
$Lights             -> add($all_flood_lights);
$Security           -> add($all_flood_lights);
$Lights             -> add($ground_hall_light);
$Lights             -> add($lounge_down_lights_near);
$Lights             -> add($front_flood_lights_west);
$Security           -> add($front_flood_lights_west);
$Lights             -> add($front_flood_lights_east);
$Security           -> add($front_flood_lights_east);
$Lights             -> add($front_door_lights);
$Security           -> add($front_door_lights);
$Lights             -> add($front_flood_lights_all);
$Security           -> add($front_flood_lights_all);
$Lights             -> add($playroom_lights_hold);
$Lights             -> add($main_bath_light);
$Ventilation        -> add($main_bath_fan);
$Heating            -> add($main_bath_heat_light_1);
$Lights             -> add($main_bath_heat_light_1);
$Heating            -> add($main_bath_heat_light_2);
$Lights             -> add($main_bath_heat_light_2);
$Lights             -> add($ensuite_light);
$Ventilation        -> add($ensuite_fan);
$Devices            -> add($rc_unit_2_channel_1);
$Wireless           -> add($rc_unit_2_channel_1);
$Devices            -> add($rc_unit_2_channel_2);
$Wireless           -> add($rc_unit_2_channel_2);
$Devices            -> add($rc_unit_2_channel_3);
$Wireless           -> add($rc_unit_2_channel_3);
$Devices            -> add($rc_unit_2_channel_4);
$Wireless           -> add($rc_unit_2_channel_4);
$Heating            -> add($ensuite_heat_light);
$Lights             -> add($ensuite_heat_light);
$Lights             -> add($garage_flood_lights_hold);
$Security           -> add($garage_flood_lights_hold);
$Lights             -> add($playroom_flood_lights_hold);
$Security           -> add($playroom_flood_lights_hold);
$Devices            -> add($rc_unit_1_channel_1);
$Wireless           -> add($rc_unit_1_channel_1);
$Devices            -> add($rc_unit_1_channel_2);
$Wireless           -> add($rc_unit_1_channel_2);
$Devices            -> add($rc_unit_1_channel_3);
$Wireless           -> add($rc_unit_1_channel_3);
$Devices            -> add($rc_unit_1_channel_4);
$Wireless           -> add($rc_unit_1_channel_4);
$Devices            -> add($ws_fnt_main);
$Sprinklers         -> add($ws_fnt_main);
$Devices            -> add($ws_fnt_side_bed);
$Sprinklers         -> add($ws_fnt_side_bed);
$Devices            -> add($ws_fnt_beds);
$Sprinklers         -> add($ws_fnt_beds);
$Devices            -> add($ws_fnt_lawn);
$Sprinklers         -> add($ws_fnt_lawn);
$Devices            -> add($ws_rear_main);
$Sprinklers         -> add($ws_rear_main);
$Devices            -> add($ws_rear_herbs);
$Sprinklers         -> add($ws_rear_herbs);
$Devices            -> add($ws_rear_garage);
$Sprinklers         -> add($ws_rear_garage);
$Devices            -> add($ws_fnt_spare1);
$Sprinklers         -> add($ws_fnt_spare1);
$Devices            -> add($ws_fnt_spare2);
$Sprinklers         -> add($ws_fnt_spare2);
$Devices            -> add($ws_fnt_spare3);
$Sprinklers         -> add($ws_fnt_spare3);
$Devices            -> add($cellar_aux_power);
$CBUS_Test          -> add($cbus_unused_unit);
#
# Create Master CBus Status Subroutine
#
sub cbus_update {

	# *****************************************************************************************
	# This subroutine is automatically generated by cgate_builder.pl, do not edit !
	# *****************************************************************************************

	my $addr = $_[0];
	my $newstate = $_[1];
	my $requestor = $_[2];

	if ($addr == 0) {
		set $garage_door $newstate;
		$garage_door->{set_by} = $requestor;
	}

	if ($addr == 1) {
		set $workshop_power $newstate;
		$workshop_power->{set_by} = $requestor;
	}

	if ($addr == 2) {
		set $playroom_lights $newstate;
		$playroom_lights->{set_by} = $requestor;
	}

	if ($addr == 3) {
		set $workshop_lights $newstate;
		$workshop_lights->{set_by} = $requestor;
	}

	if ($addr == 4) {
		set $playroom_toilet_light $newstate;
		$playroom_toilet_light->{set_by} = $requestor;
	}

	if ($addr == 5) {
		set $playroom_lights_all $newstate;
		$playroom_lights_all->{set_by} = $requestor;
	}

	if ($addr == 6) {
		set $front_garden_path_lights $newstate;
		$front_garden_path_lights->{set_by} = $requestor;
	}

	if ($addr == 7) {
		set $playroom_flood_lights $newstate;
		$playroom_flood_lights->{set_by} = $requestor;
	}

	if ($addr == 8) {
		set $garage_flood_lights $newstate;
		$garage_flood_lights->{set_by} = $requestor;
	}

	if ($addr == 9) {
		set $front_garden_gpo $newstate;
		$front_garden_gpo->{set_by} = $requestor;
	}

	if ($addr == 10) {
		set $lounge_wall_lights $newstate;
		$lounge_wall_lights->{set_by} = $requestor;
	}

	if ($addr == 11) {
		set $cellar_door_light $newstate;
		$cellar_door_light->{set_by} = $requestor;
	}

	if ($addr == 12) {
		set $cbus_test_unit $newstate;
		$cbus_test_unit->{set_by} = $requestor;
	}

	if ($addr == 16) {
		set $lounge_down_lights_centre $newstate;
		$lounge_down_lights_centre->{set_by} = $requestor;
	}

	if ($addr == 17) {
		set $lounge_down_lights_far $newstate;
		$lounge_down_lights_far->{set_by} = $requestor;
	}

	if ($addr == 18) {
		set $all_flood_lights $newstate;
		$all_flood_lights->{set_by} = $requestor;
	}

	if ($addr == 19) {
		set $ground_hall_light $newstate;
		$ground_hall_light->{set_by} = $requestor;
	}

	if ($addr == 20) {
		set $lounge_down_lights_near $newstate;
		$lounge_down_lights_near->{set_by} = $requestor;
	}

	if ($addr == 21) {
		set $front_flood_lights_west $newstate;
		$front_flood_lights_west->{set_by} = $requestor;
	}

	if ($addr == 22) {
		set $front_flood_lights_east $newstate;
		$front_flood_lights_east->{set_by} = $requestor;
	}

	if ($addr == 23) {
		set $front_door_lights $newstate;
		$front_door_lights->{set_by} = $requestor;
	}

	if ($addr == 24) {
		set $front_flood_lights_all $newstate;
		$front_flood_lights_all->{set_by} = $requestor;
	}

	if ($addr == 25) {
		set $playroom_lights_hold $newstate;
		$playroom_lights_hold->{set_by} = $requestor;
	}

	if ($addr == 27) {
		set $main_bath_light $newstate;
		$main_bath_light->{set_by} = $requestor;
	}

	if ($addr == 28) {
		set $main_bath_fan $newstate;
		$main_bath_fan->{set_by} = $requestor;
	}

	if ($addr == 29) {
		set $main_bath_heat_light_1 $newstate;
		$main_bath_heat_light_1->{set_by} = $requestor;
	}

	if ($addr == 30) {
		set $main_bath_heat_light_2 $newstate;
		$main_bath_heat_light_2->{set_by} = $requestor;
	}

	if ($addr == 31) {
		set $ensuite_light $newstate;
		$ensuite_light->{set_by} = $requestor;
	}

	if ($addr == 32) {
		set $ensuite_fan $newstate;
		$ensuite_fan->{set_by} = $requestor;
	}

	if ($addr == 33) {
		set $rc_unit_2_channel_1 $newstate;
		$rc_unit_2_channel_1->{set_by} = $requestor;
	}

	if ($addr == 34) {
		set $rc_unit_2_channel_2 $newstate;
		$rc_unit_2_channel_2->{set_by} = $requestor;
	}

	if ($addr == 35) {
		set $rc_unit_2_channel_3 $newstate;
		$rc_unit_2_channel_3->{set_by} = $requestor;
	}

	if ($addr == 36) {
		set $rc_unit_2_channel_4 $newstate;
		$rc_unit_2_channel_4->{set_by} = $requestor;
	}

	if ($addr == 37) {
		set $ensuite_heat_light $newstate;
		$ensuite_heat_light->{set_by} = $requestor;
	}

	if ($addr == 38) {
		set $garage_flood_lights_hold $newstate;
		$garage_flood_lights_hold->{set_by} = $requestor;
	}

	if ($addr == 39) {
		set $playroom_flood_lights_hold $newstate;
		$playroom_flood_lights_hold->{set_by} = $requestor;
	}

	if ($addr == 40) {
		set $rc_unit_1_channel_1 $newstate;
		$rc_unit_1_channel_1->{set_by} = $requestor;
	}

	if ($addr == 41) {
		set $rc_unit_1_channel_2 $newstate;
		$rc_unit_1_channel_2->{set_by} = $requestor;
	}

	if ($addr == 42) {
		set $rc_unit_1_channel_3 $newstate;
		$rc_unit_1_channel_3->{set_by} = $requestor;
	}

	if ($addr == 43) {
		set $rc_unit_1_channel_4 $newstate;
		$rc_unit_1_channel_4->{set_by} = $requestor;
	}

	if ($addr == 44) {
		set $ws_fnt_main $newstate;
		$ws_fnt_main->{set_by} = $requestor;
	}

	if ($addr == 45) {
		set $ws_fnt_side_bed $newstate;
		$ws_fnt_side_bed->{set_by} = $requestor;
	}

	if ($addr == 46) {
		set $ws_fnt_beds $newstate;
		$ws_fnt_beds->{set_by} = $requestor;
	}

	if ($addr == 47) {
		set $ws_fnt_lawn $newstate;
		$ws_fnt_lawn->{set_by} = $requestor;
	}

	if ($addr == 48) {
		set $ws_rear_main $newstate;
		$ws_rear_main->{set_by} = $requestor;
	}

	if ($addr == 49) {
		set $ws_rear_herbs $newstate;
		$ws_rear_herbs->{set_by} = $requestor;
	}

	if ($addr == 50) {
		set $ws_rear_garage $newstate;
		$ws_rear_garage->{set_by} = $requestor;
	}

	if ($addr == 51) {
		set $ws_fnt_spare1 $newstate;
		$ws_fnt_spare1->{set_by} = $requestor;
	}

	if ($addr == 52) {
		set $ws_fnt_spare2 $newstate;
		$ws_fnt_spare2->{set_by} = $requestor;
	}

	if ($addr == 53) {
		set $ws_fnt_spare3 $newstate;
		$ws_fnt_spare3->{set_by} = $requestor;
	}

	if ($addr == 54) {
		set $cellar_aux_power $newstate;
		$cellar_aux_power->{set_by} = $requestor;
	}

	if ($addr == 255) {
		set $cbus_unused_unit $newstate;
		$cbus_unused_unit->{set_by} = $requestor;
	}

}
#
#
# EOF
#
#
