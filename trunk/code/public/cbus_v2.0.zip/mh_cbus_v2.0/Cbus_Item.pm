# Inheritence package for CBUS items
# All Cbus_items are in fact Generic_Items, unless declared or defined here

use strict;

package Cbus_Item;

@Cbus_Item::ISA = ('Generic_Item');




#
# $Log: Cbus_Item.pm,v $
# Revision 1.00  2001/12/27 21:00:00  morgan
#
#

1;
