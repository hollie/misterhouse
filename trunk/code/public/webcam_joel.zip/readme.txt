From Joel Davidson on 1/2004

I've attached the 2 scripts I use to capture the image from my front door
camera (which is modulated on channel 89), and my garage camera (which
is a logitech usb camera).  It seemed that at boot time the system was
inconsistant as to which of the usb camera and the Hauppauge video card
got assigned as /dev/video0 and /dev/video1, so both scripts start by
looking in /proc/video to determine which is which.  In both scripts,
if they are called with an argument 'mail', the resulting jpeg is
copied to /tmp with the current date and time as part of the filename.
Otherwise the images are left in the mh web/ia5/security/captures directory.
