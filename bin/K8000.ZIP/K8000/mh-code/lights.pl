# Category=Lights

#@ Controls various lights.

#Some global variables
my $dimmer_states = 'on,brighten,dim,off,minus 10,plus 10,minus 30,minus 50,minus 80,plus 30,plus 50,plus 80,plus 100,minus 100,reverse';
my $light_states = 'on,off,reverse';

#define the voice commands and actions
$night_light_katrien = new  Voice_Cmd("Night light one [$dimmer_states]");
$dimmer1_timer = new Timer;
if ($state = $night_light_katrien->{said}) {
	set $DAC1 '64' if $state eq 'on';
	set $DAC1 '1' if $state eq 'off';
	set_with_timer $DAC1, 0, 'previous' if $state eq 'reverse';
	set $dimmer1_timer 0.1, sub{ set $DAC1 (state $DAC1 + 1) if (state $DAC1 <= 63)},6 if ('brighten' eq $state) or ('plus 10' eq $state);
	set $dimmer1_timer 0.1, sub{ set $DAC1 (state $DAC1 - 1) if (state $DAC1 >= 1)},6 if ('dim' eq $state) or ('minus 10' eq $state);
	set $dimmer1_timer 0.1, sub{ set $DAC1 (state $DAC1 + 1) if (state $DAC1 <= 63)},19 if ('plus 30' eq $state);
	set $dimmer1_timer 0.1, sub{ set $DAC1 (state $DAC1 - 1) if (state $DAC1 >= 1)},19 if ('minus 30' eq $state);
	set $dimmer1_timer 0.1, sub{ set $DAC1 (state $DAC1 + 1) if (state $DAC1 <= 63)},32 if ('plus 50' eq $state);
	set $dimmer1_timer 0.1, sub{ set $DAC1 (state $DAC1 - 1) if (state $DAC1 >= 1)},32 if ('minus 50' eq $state);
	set $dimmer1_timer 0.1, sub{ set $DAC1 (state $DAC1 + 1) if (state $DAC1 <= 63)},51 if ('plus 80' eq $state);
	set $dimmer1_timer 0.1, sub{ set $DAC1 (state $DAC1 - 1) if (state $DAC1 >= 1)},51 if ('minus 80' eq $state);
	set $dimmer1_timer 0.1, sub{ set $DAC1 (state $DAC1 + 1) if (state $DAC1 <= 63)},64 if ('plus 100' eq $state);
	set $dimmer1_timer 0.1, sub{ set $DAC1 (state $DAC1 - 1) if (state $DAC1 >= 1)},64 if ('minus 100' eq $state);
}

$night_light_nico = new  Voice_Cmd("Night light two [$dimmer_states]");
$dimmer2_timer = new Timer;
if ($state = $night_light_nico->{said}) {
        set $DAC2 '64' if $state eq 'on';
        set $DAC2 '1' if $state eq 'off';
        set_with_timer $DAC2, 0, 'previous' if $state eq 'reverse';
        set $dimmer2_timer 0.1, sub{ set $DAC2 (state $DAC2 + 1) if (state $DAC2 <= 63)},6 if ('brighten' eq $state);
        set $dimmer2_timer 0.1, sub{ set $DAC2 (state $DAC2 - 1) if (state $DAC2 >= 1)},6 if ('dim' eq $state);
        set $dimmer2_timer 0.1, sub{ set $DAC2 (state $DAC2 + 1) if (state $DAC2 <= 63)},19 if ('plus 30' eq $state);
        set $dimmer2_timer 0.1, sub{ set $DAC2 (state $DAC2 - 1) if (state $DAC2 >= 1)},19 if ('minus 30' eq $state);
        set $dimmer2_timer 0.1, sub{ set $DAC2 (state $DAC2 + 1) if (state $DAC2 <= 63)},32 if ('plus 50' eq $state);
        set $dimmer2_timer 0.1, sub{ set $DAC2 (state $DAC2 - 1) if (state $DAC2 >= 1)},32 if ('minus 50' eq $state);
        set $dimmer2_timer 0.1, sub{ set $DAC2 (state $DAC2 + 1) if (state $DAC2 <= 63)},51 if ('plus 80' eq $state);
        set $dimmer2_timer 0.1, sub{ set $DAC2 (state $DAC2 - 1) if (state $DAC2 >= 1)},51 if ('minus 80' eq $state);
        set $dimmer2_timer 0.1, sub{ set $DAC2 (state $DAC2 + 1) if (state $DAC2 <= 63)},64 if ('plus 100' eq $state);
        set $dimmer2_timer 0.1, sub{ set $DAC2 (state $DAC2 - 1) if (state $DAC2 >= 1)},64 if ('minus 100' eq $state);
}

$webcam_light = new Voice_Cmd("Web light [$light_states]");
if ($state = $webcam_light->{said}) {
	set $IO12 'on' if $state eq 'on';
	set $IO12 'off' if $state eq 'off';
	set_with_timer $IO12, 0, 'previous' if $state eq 'reverse';
}



