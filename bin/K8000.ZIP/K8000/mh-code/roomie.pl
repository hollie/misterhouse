# Category=Lights

#@ Controls various lights.



### Actions on triggers

######### Simulate one button dimmer controller ##################
my $pressed = new Timer;
my $teller1 = 0;
my $teller2 = 0;
my $timer1 = new Timer;
my $timer2 = new Timer;
if ($state = state_changed $IO3){
	print_log "roomie Druk knop 1 $state";	
	if ($state eq 'on') {$teller1 = 1; set $pressed 1;}
	if ($state eq 'off') {
		if (active $pressed){ 
			set $DAC1 '64' if state $DAC1 <= 15;
			set $DAC1 '1' if state $DAC1 > 15;
		}
	$teller1 = 0;
	}
}
if ($teller1 and (inactive $pressed)) { set $DAC1 (state $DAC1 + 1);}

if ($state = state_changed $IO4){
	print_log "Druk knop 2 $state";	
	if ($state eq 'on') {$teller2 = 1; set $pressed 1;}
	if ($state eq 'off') {
		if (active $pressed){ 
			set $DAC2 '64' if state $DAC2 <= 15;
			set $DAC2 '1' if state $DAC2 > 15;
		}
	$teller2 = 0;
	}
}

if ($teller2 and (inactive $pressed)) { set $DAC2 (state $DAC2 + 1);}


if ($state = state_changed $IO1){
	print_log "Druk knop 3 $state";	
	if ($state eq 'on') {run_voice_cmd "sleep mode";}
}

if ($state = state_changed $IO2){
	print_log "Druk knop 4 $state";	
	if ($state eq 'on') {run_voice_cmd "tv mode";}
}
if ($state = state_changed $IO5){
	print_log "Druk knop 5 $state";	
	if ($state eq 'on') {run_voice_cmd "Radio Start";}
}
######## END one button dimmer controller ########################

## TV mode ##
# Stop the radio
# Start the TV
# dim or brighten the bedroom night lights to 20
$TV_mode = new Voice_Cmd "TV mode";
if (said $TV_mode) {
	run_voice_cmd "Radio Stop";
	if (state $TV eq 'Stop'){ run_voice_cmd "TV Start";} else {run_voice_cmd "TV Stop";}
	if ($Dark){
		set $timer1 0.2, sub{ set $DAC1 (state $DAC1 + 1)}, (20 - state $DAC1) if state $DAC1 < 20;
		set $timer2 0.2, sub{ set $DAC2 (state $DAC2 + 1)}, (20 - state $DAC2) if state $DAC2 < 20;
		set $timer1 0.2, sub{ set $DAC1 (state $DAC1 - 1)}, (state $DAC1 - 20) if state $DAC1 > 20;
		set $timer2 0.2, sub{ set $DAC2 (state $DAC2 - 1)}, (state $DAC2 - 20) if state $DAC1 > 20;
	}
}

## SLEEP mode ##
# Stop the radio
# Stop the TV
# dim the lights to off
$sleep_mode = new Voice_Cmd "sleep mode";
if (said $sleep_mode) {
	run_voice_cmd "Radio Stop";
	run_voice_cmd "TV Stop";
	run_voice_cmd "Put house in mute mode";
	set $timer1 0.3, sub{ set $DAC1 (state $DAC1 - 1)}, (state $DAC1);
	set $timer2 0.3, sub{ set $DAC2 (state $DAC2 - 1)}, (state $DAC2);
}

$main_volume = new Voice_Cmd "Volume [up,down]";
if ($state = said $main_volume) {
	set $mh_volume (state $mh_volume + 1) if $state eq 'up';
	set $mh_volume (state $mh_volume - 1) if $state eq 'down';
}

# Put the house in mute mode between 23:00 and 08:00
if ($Time_Now eq '23:00:00') {
	run_voice_cmd "Put house in mute mode";
}
