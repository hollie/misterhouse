######Initialize the socket to talk to the k8000d deamon ###################

#Define the IP address and the port the k8000d is listening, in this case port 30000 on the same machine.
my $k8000_server_adress = '127.0.0.1:30000';
$k8000_socket = new Socket_Item(undef, undef, $k8000_server_adress, 'k8000_client');
if ($Startup) {start $k8000_socket ;} #Starting the socket
# Global variables

my $IOstates = (ON, OFF);
# Startup setings restore.
#todo

#Generating the IO variables for use in other code:
$IO1 = new Generic_Item;
$IO1 -> set_states($IOstates);

$IO2 = new Generic_Item;
$IO2 -> set_states($IOstates);

$IO3 = new Generic_Item;
$IO3 -> set_states($IOstates);

$IO4 = new Generic_Item;
$IO4 -> set_states($IOstates);

$IO5 = new Generic_Item;
$IO5 -> set_states($IOstates);

$IO6 = new Generic_Item;
$IO6 -> set_states($IOstates);

$IO7 = new Generic_Item;
$IO7 -> set_states($IOstates);

$IO8 = new Generic_Item;
$IO8 -> set_states($IOstates);

$IO9 = new Generic_Item;
$IO9 -> set_states($IOstates);

$IO10 = new Generic_Item;
$IO10 -> set_states($IOstates);

$IO11 = new Generic_Item;
$IO11 -> set_states($IOstates);

$IO12 = new Generic_Item;
$IO12 -> set_states($IOstates);

$IO13 = new Generic_Item;
$IO13 -> set_states($IOstates);

$IO14 = new Generic_Item;
$IO14 -> set_states($IOstates);

$IO15 = new Generic_Item;
$IO15 -> set_states($IOstates);

$IO16 = new Generic_Item;
$IO16 -> set_states($IOstates);

$DAC1 = new Generic_Item;

$DAC2 = new Generic_Item;

$DAC3 = new Generic_Item;

$DAC4 = new Generic_Item;

$DAC5 = new Generic_Item;

$DAC6 = new Generic_Item;

$DA1 = new Generic_Item;

$AD1 = new Generic_Item;

$AD2 = new Generic_Item;

$AD3 = new Generic_Item;

$AD4 = new Generic_Item;

#Updating the values for the outputs if changed
if ($state = state_now $IO8)  {
        print_log "IO 8 state changed to $state";
        set $k8000_socket "setIO08on" if $state eq 'on';
        set $k8000_socket "setIO08of" if $state eq 'off';
}

if ($state = state_now $IO9)  {
        print_log "IO 9 state changed to $state";
        set $k8000_socket "setIO09on" if $state eq 'on';
        set $k8000_socket "setIO09of" if $state eq 'off';
}

if ($state = state_now $IO10)  {
        print_log "IO 10 state changed to $state";
        set $k8000_socket "setIO10on" if $state eq 'on';
        set $k8000_socket "setIO10of" if $state eq 'off';
}

if ($state = state_now $IO11)  {
        print_log "IO 11 state changed to $state";
        set $k8000_socket "setIO11on" if $state eq 'on';
        set $k8000_socket "setIO11of" if $state eq 'off';
}

if ($state = state_now $IO12)  {
        print_log "IO 12 state changed to $state";
        set $k8000_socket "setIO12on" if $state eq 'on';
        set $k8000_socket "setIO12of" if $state eq 'off';
}

if ($state = state_now $IO13)  {
        print_log "IO 13 state changed to $state";
        set $k8000_socket "setIO13on" if $state eq 'on';
        set $k8000_socket "setIO13of" if $state eq 'off';
}

if ($state = state_now $IO14)  {
        print_log "IO 14 state changed to $state";
        set $k8000_socket "setIO14on" if $state eq 'on';
        set $k8000_socket "setIO14of" if $state eq 'off';
}

if ($state = state_now $IO15)  {
        print_log "IO 15 state changed to $state";
        set $k8000_socket "setIO15on" if $state eq 'on';
        set $k8000_socket "setIO15of" if $state eq 'off';
}

if ($state = state_now $IO16)  {
        print_log "IO 16 state changed to $state";
        set $k8000_socket "setIO16on" if $state eq 'on';
        set $k8000_socket "setIO16of" if $state eq 'off';
}

if ($state = state_now $DAC1)  {
        print_log "DAC 1 state changed to $state";
	set $DAC1 '64' if state $DAC1 > 64;
	set $DAC1 '0' if state $DAC1 < 0;
        set $k8000_socket "setDC01$state" if ($state >= 0 and $state <= 64);
}

if ($state = state_now $DAC2)  {
        print_log "DAC 2 state changed to $state";
	set $DAC2 '64' if state $DAC2 > 64;
	set $DAC2 '0' if state $DAC2 < 0;
        set $k8000_socket "setDC02$state" if ($state >= 0 and $state <= 64);
}
my $i;
my $test;
my $waarde;
#Updating the IO input and DA channels every 100 milisecond.
if ($New_Msecond_100) {
	set $k8000_socket "getio";
	if ($state = said $k8000_socket) {
		print_log "$state received from socket";
		$test = substr($state, 3, 1);
		if ($state =~/IO/){
			if ($state =~/on/){
				set $IO1 'on' if $test eq 1;
				set $IO2 'on' if $test eq 2;
				set $IO3 'on' if $test eq 3;
				set $IO4 'on' if $test eq 4;
				set $IO5 'on' if $test eq 5;
				set $IO6 'on' if $test eq 6;
				print_log "IO$test set to on";
			} 
			if ($state =~/off/){
				set $IO1 'off' if $test eq 1;
				set $IO2 'off' if $test eq 2;
				set $IO3 'off' if $test eq 3;
				set $IO4 'off' if $test eq 4;
				set $IO5 'off' if $test eq 5;
				set $IO6 'off' if $test eq 6;
				print_log "IO$test set to off";
			}
		}
	}
}

#Updating the AD channels every minute.
if ($New_Minute) {
        set $k8000_socket "getad";
        if ($state = said $k8000_socket) {
                print_log "$state received from socket";
		if ($state =~/AD/){
			$test = substr($state, 3, 2);
			$waarde = substr($state, 9, 3);
			print_log "AD$test set to $waarde";	
			$AD1 = $waarde if $test eq 1;
			$AD2 = $waarde if $test eq 2;
			$AD3 = $waarde if $test eq 3;
			$AD4 = $waarde if $test eq 4;
		}
	}	
}
