This is a TCP/IP socket for the velleman k8000 IO board.
This software will create a tcp/ip socket to interface the k8000 board under linux.
Just type 'make'
This will create the executable k8000d
Start this executable.
You have now a socket listening on port 30000
Note that all variables like listening port and IO settings are hard coded for the moment.
To test you can telnet to the port and try to set or get some values.

Have fun,
For more info mail to nico@yow.be or visit www.yow.be for newer versions or beter documentation ;-)

Grtz,
Nico
