#include "ServerSocket.h"
#include "SocketException.h"
#include <string>
#include <iostream.h>
#include <k8000.h>
#include <errno.h>
#include <stdlib.h>
using namespace std;



int main ( int argc, int argv[] )
{
  std::cout << "running....\n";
  // The Velleman K8000 is connected to parallel port 1
  // If you use the /dev/velleman interface, specify -1 or I2C_DEV
  if(SelectI2CprinterPort(1))
  {
    cout << "Error selecting the correct interface (remember to run as root) : " << strerror(errno)<<endl;
    exit(1);
  }

//Here we initialize the card.
//A '1' stands for IO chip set as input and a '0' means IO chip set as output.
char instellingen[16] = {1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0};
int i;
short IOold[6] = {0,0,0,0,0,0}, ADold[4] = {0,0,0,0};
int nummer, waarde;
char converter[1];
char result[4];
for ( i = 0; i <= 15; i++) {
        if (instellingen[ i ] == 1 )  ConfigIOchannelAsInput(i+1);
        else {
                ConfigIOchannelAsOutput(i+1);
        }
}

  try
    {
      // Create the socket
      ServerSocket server ( 30000 );

      while ( true )
	{

	  ServerSocket new_sock;
	  server.accept ( new_sock );

	  try
	    {
	      while ( true )
		{
		  std::string data;
		  new_sock >> data;
                  if (data.substr(0,5) == "getio"){ 
			for ( i = 0; i <= 5; i++){
			 ReadIOchannel(i);
			 if (IO[i] == IOold[i]){}
			else {
				IOold[i] = IO[i];
				sprintf(converter,"%d",i);
				if (IO[i]) {
					new_sock << "IO " << converter << " on\n";
					cout << "IO" << converter << " on\n";
				}
				else {
					new_sock << "IO " << converter << " off\n";
					cout << "IO" << converter << " off\n";
				}
			}
			}
		}
                  if (data.substr(0,5) == "getad"){ 
			ReadAllAD();
			for ( i = 0; i <= 3; i++){
				if (AD[i] == ADold[i]){}
				else {
					ADold[i] = AD[i];
                         		sprintf(result,"%d",AD[i]);
					sprintf(converter,"%d",i);
                         		new_sock << "AD " << converter << " now " << result << "\n";
				}
			}
                  }
                  if (data.substr(0,3) == "set"){
                          if (data.substr(3,2) == "IO"){
                                  string number = data.substr(5,2);
				nummer = atoi(number.c_str());
                                  if (data.substr(7,2) == "on"){
                                         SetIOchannel(nummer);
                                  }
                                  if (data.substr(7,2) == "of"){
                                          ClearIOchannel(nummer);
                                  }
                          }
                          if (data.substr(3,2) == "DC"){
                                  string number = data.substr(5,2);
				nummer = atoi(number.c_str());
                                  string value = data.substr(7,2);
				waarde = atoi(value.c_str());
                                  cout << "Ok DAC channel " << nummer << "  set to " << waarde << "\n";
                                  OutputDACchannel(nummer, waarde);
                          }
                          if (data.substr(3,2) == "DA"){
                                  string number = data.substr(5,2);
				nummer = atoi(number.c_str());
                                  string value = data.substr(7,3);
				waarde = atoi(value.c_str());
                                  cout << "Ok DA channel " << nummer << " set to " << waarde << "\n";
                                  OutputDAchannel(nummer, waarde);
                          }
                  }

		}
	    }
	  catch ( SocketException& ) {}

	}
    }
  catch ( SocketException& e )
    {
      std::cout << "Exception was caught:" << e.description() << "\nExiting.\n";
    }

  return 0;
}
